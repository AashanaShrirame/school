package com.school;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SchoolPortalApplication {

	public static void main(String[] args) {
		SpringApplication.run(SchoolPortalApplication.class, args);
	}

}
